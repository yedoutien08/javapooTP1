package models;

import javax.swing.*;

public class BoiteDialogueTest {
    public static void main(String[] args) {
        String nom=JOptionPane.showInputDialog("quel est ton nom?");
        String message= String.format("salut %s. java est cool n'est ce pas?", nom);
        JOptionPane.showMessageDialog(null,message);
    }
}
