/*package models;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;



public class Capitalegames
{

    public static void main(String[] args)
    {

        final int NUMBER_OF_QUESTION =5;
        int score = 0, index;
        String pays, capital, username;
        char replayAnser;

        ArrayList<Integer> indexAlreadyTaken=new ArrayList<>();
        String[] [] data= getData();
        Scanner clavier= new Scanner(System.in);
        do{
            indexAlreadyTaken.clear();
            do {
                Random random = new Random();
                index = random.nextInt(data.length);
            }
            while (indexAlreadyTaken.contains(index));
            indexAlreadyTaken.add(index);


            //  }


            //       }

            //       }

            //   private static String[][] getData() {
//     return new String[0][];
//   }


            //  }
            do {
                Random random = new Random();
                index = random.nextInt(data.length);
            }
            while (indexAlreadyTaken.contains(index));
            indexAlreadyTaken.add(index);


            //  }


            //       }

            //       }

            //   private static String[][] getData() {
//     return new String[0][];
//   }


            //  }
            do {
                Random random = new Random();
                index = random.nextInt(data.length);
            }
            while (indexAlreadyTaken.contains(index));
            indexAlreadyTaken.add(index);


            //  }


            //       }

            //       }

            //   private static String[][] getData() {
//     return new String[0][];
//   }


            //  }
            do {
                Random random = new Random();
                index = random.nextInt(data.length);
            }
            while (indexAlreadyTaken.contains(index));
            indexAlreadyTaken.add(index);


            //  }


            //       }

            //       }

            //   private static String[][] getData() {
//     return new String[0][];
//   }


            //  }
            do {
                Random random = new Random();
                index = random.nextInt(data.length);
            }
            while (indexAlreadyTaken.contains(index));
            indexAlreadyTaken.add(index);


            //  }


            //       }

            //       }

            //   private static String[][] getData() {
//     return new String[0][];
//   }


            //  }
*/