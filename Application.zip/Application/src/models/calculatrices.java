package models;

public class calculatrices {
    private double resultat;

    public double additionner(double... nombres){
        for(double nombre:nombres){
        resultat+=nombre;
    }
    public double getResultat(){
        return resultat;
    }
}
