package models;

//import static java.lang.Math.

public class Personne {
    public String Nom;
    private int age;
    //constante
    public final int NOMBREMAXOREIL=2;

 //   public int getAge() {
  //      return age*365;
  //  }
  //  public String full_title()
   //     return String.format()

    public void setAge(int age) {
        if(age<12) {
            System.out.println("ce n'est pas permis au moin de 12 ans");
        }else
        this.age = age;
    }
}
