package models;

import javax.swing.*;

public class tp1boitedialogue {
    public static void main(String[] args) {
       int nombre1= Integer.parseInt(JOptionPane.showInputDialog("entrer le premiere nombre"));
       int nombre2=Integer.parseInt(JOptionPane.showInputDialog("entrer le deuxieme nombre"));
        String message = String.format("la somme de %d et %d est  %d ", nombre1, nombre2);

        JOptionPane.showMessageDialog(null,message);
    }
}
