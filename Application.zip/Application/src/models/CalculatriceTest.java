package models;

public class CalculatriceTest {
    public static void main(String[] args) {
        calculatrices calculatrice=new calculatrices();
        calculatrice.additionner(6);
        calculatrice.additionner(6);
        calculatrice.additionner(6);
        calculatrice.additionner(6);
        System.out.println(calculatrice.getResultat());

    }
    }

