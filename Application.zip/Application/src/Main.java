import models.Personne;

public class Main {
    public static void main(String[] args) {
        Personne p1=new Personne();
        p1.setAge(11);
    //    System.out.println(p1.getAge());
    }
}